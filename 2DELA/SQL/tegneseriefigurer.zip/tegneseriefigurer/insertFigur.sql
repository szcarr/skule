INSERT INTO `tegneseriefigurer`.`figur` (`figurnavn`, `aarstall`, `blad_id`) VALUES ('Onkel Skrue', '1968', '2');
