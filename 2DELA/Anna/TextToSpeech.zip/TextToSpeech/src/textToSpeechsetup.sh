sudo apt update
sudo apt upgrade -y
sudo apt install espeak -y
sudo apt install fortune -y